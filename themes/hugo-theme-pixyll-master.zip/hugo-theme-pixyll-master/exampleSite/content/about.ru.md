+++
date = "2014-11-08T16:42:18+04:00"
draft = false
title = "О нас"
slug = "about"

+++

Пару слов о проекте.
