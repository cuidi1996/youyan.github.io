+++
title = "Is that a cooking show?"
date = "2017-08-30T18:34:02+00:00"
tags = ["futurama"]
draft = false
author = "admin"
+++

With a warning label this big, you know they gotta be fun! Son, as your lawyer, I declare y'all are in a 12-piece bucket o' trouble. But I done struck you a deal: Five hours of community service cleanin' up that ol' mess you caused.

Why, those are the Grunka-Lunkas! They work here in the Slurm factory. Hi, I'm a naughty nurse, and I really need someone to talk to. $9. 95 a minute. Oh, how awful. Did he at least die painlessly? …To shreds, you say. Well, how is his wife holding up? …To shreds, you say.

## Do a flip!

She also liked to shut up! Belligerent and numerous. Uh, is the puppy mechanical in any way? Is that a cooking show? I found what I need. And it's not friends, it's things.

1. Ven ve voke up, ve had zese wodies.
2. Oh, I think we should just stay friends.
3. Can we have Bender Burgers again?
## Hello Morbo, how's the family?

Please, Don-Bot… look into your hard drive, and open your mercy file! Who am I making this out to? It's okay, Bender. I like cooking too. Oh, but you can. But you may have to metaphorically make a deal with the devil. And by "devil", I mean Robot Devil. And by "metaphorically", I mean get your coat.

* My fellow Earthicans, as I have explained in my book 'Earth in the Balance'', and the much more popular ''Harry Potter and the Balance of Earth', we need to defend our planet against pollution. Also dark wizards.
* Ummm…to eBay?
* One hundred dollars.
Stop it, stop it. It's fine. I will 'destroy' you! Alright, let's mafia things up a bit. Joey, burn down the ship. Clamps, burn down the crew. Calculon is gonna kill us and it's all everybody else's fault!

There, now he's trapped in a book I wrote: a crummy world of plot holes and spelling errors! And when we woke up, we had these bodies. When will that be? Fatal. Oh, all right, I am. But if anything happens to me, tell them I died robbing some old man.

Morbo can't understand his teleprompter because he forgot how you say that letter that's shaped like a man wearing a hat. Bender?! You stole the atom. What are their names? Yeah, and if you were the pope they'd be all, "Straighten your pope hat." And "Put on your good vestments."

I don't 'need' to drink. I can quit anytime I want! Shut up and take my money! Hey, whatcha watching? You mean while I'm sleeping in it? No, she'll probably make me do it. Yes, if you make it look like an electrical fire. When you do things right, people won't be sure you've done anything at all.

This is the worst part. The calm before the battle. It must be wonderful. Shut up and take my money! Hey, tell me something. You've got all this money. How come you always dress like you're doing your laundry?

Five hours? Aw, man! Couldn't you just get me the death penalty? With gusto. Our love isn't any different from yours, except it's hotter, because I'm involved. Oh Leela! You're the only person I could turn to; you're the only person who ever loved me.

Bender, this is Fry's decision… and he made it wrong. So it's time for us to interfere in his life. I was all of history's great robot actors - Acting Unit 0.8; Thespomat; David Duchovny! Hey, you add a one and two zeros to that or we walk!

No! The cat shelter's on to me. Shinier than yours, meatbag. Morbo can't understand his teleprompter because he forgot how you say that letter that's shaped like a man wearing a hat. We're also Santa Claus!

Fry! Quit doing the right thing, you jerk! Good man. Nixon's pro-war and pro-family. Then throw her in the laundry room, which will hereafter be referred to as "the brig". You've killed me! Oh, you've killed me!

Fry, you can't just sit here in the dark listening to classical music. And why did 'I' have to take a cab? You know, I was God once. Hello Morbo, how's the family? Tell her she looks thin.

I don't know what you did, Fry, but once again, you screwed up! Now all the planets are gonna start cracking wise about our mamas. Okay, I like a challenge. So, how 'bout them Knicks? Ummm…to eBay?

Generated with [fillerama](http://fillerama.io).
